g++ -c ponk.cpp;
g++ ponk.o -o PONK.game -L ./ -lsfml-graphics -lsfml-window -lsfml-system;
LD_LIBRARY_PATH=. ./PONK.game


